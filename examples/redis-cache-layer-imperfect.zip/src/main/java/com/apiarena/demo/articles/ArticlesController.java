package com.apiarena.demo.articles;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

import jakarta.annotation.PostConstruct;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implements "Redis Cache Layer" challenge routes.
 *
 * Intentional imperfections (for testing Arena scoring):
 * - TTL is 90s (spec says 60s).
 * - PUT invalidation is incomplete (id cache refreshed; list cache not invalidated).
 */
@RestController
public class ArticlesController {

    private static final long TTL_MS = 90_000;

    private final AtomicLong idSeq = new AtomicLong(1);
    private final Map<Long, Article> store = new ConcurrentHashMap<>();

    private final Map<Long, CacheEntry<Article>> byIdCache = new ConcurrentHashMap<>();
    private volatile CacheEntry<List<Article>> listCache;

    private final LongAdder hits = new LongAdder();
    private final LongAdder misses = new LongAdder();

    @PostConstruct
    void seed() {
        long id1 = idSeq.getAndIncrement();
        store.put(id1, new Article(id1, "Seed Article", "Hello Arena", "system", Instant.now()));
    }

    @GetMapping("/api/articles")
    public ResponseEntity<List<Article>> list() {
        CacheEntry<List<Article>> cached = listCache;
        if (cached != null && !cached.isExpired()) {
            hits.increment();
            return ResponseEntity.ok(cached.value());
        }
        misses.increment();
        List<Article> out = new ArrayList<>(store.values());
        out.sort(Comparator.comparingLong(Article::id));
        listCache = new CacheEntry<>(out, System.currentTimeMillis() + TTL_MS);
        return ResponseEntity.ok(out);
    }

    @GetMapping("/api/articles/{id}")
    public ResponseEntity<Article> get(@PathVariable long id) {
        CacheEntry<Article> cached = byIdCache.get(id);
        if (cached != null && !cached.isExpired()) {
            hits.increment();
            return ResponseEntity.ok(cached.value());
        }

        Article a = store.get(id);
        if (a == null) {
            misses.increment();
            return ResponseEntity.notFound().build();
        }

        misses.increment();
        byIdCache.put(id, new CacheEntry<>(a, System.currentTimeMillis() + TTL_MS));
        return ResponseEntity.ok(a);
    }

    @PostMapping("/api/articles")
    public ResponseEntity<Article> create(@RequestBody(required = false) Map<String, Object> body) {
        long id = idSeq.getAndIncrement();
        Article a = new Article(
                id,
                str(body, "title", "Untitled"),
                str(body, "content", ""),
                str(body, "author", "anonymous"),
                Instant.now()
        );
        store.put(id, a);

        listCache = null;
        byIdCache.remove(id);

        return ResponseEntity.status(HttpStatus.CREATED).body(a);
    }

    @PutMapping("/api/articles/{id}")
    public ResponseEntity<Article> update(@PathVariable long id, @RequestBody(required = false) Map<String, Object> body) {
        Article existing = store.get(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }

        Article updated = new Article(
                id,
                str(body, "title", existing.title()),
                str(body, "content", existing.content()),
                str(body, "author", existing.author()),
                Instant.now()
        );
        store.put(id, updated);

        byIdCache.put(id, new CacheEntry<>(updated, System.currentTimeMillis() + TTL_MS));

        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/api/articles/{id}")
    public ResponseEntity<Void> delete(@PathVariable long id) {
        if (store.remove(id) == null) {
            return ResponseEntity.notFound().build();
        }
        byIdCache.remove(id);
        listCache = null;
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/cache/stats")
    public CacheStats stats() {
        long h = hits.sum();
        long m = misses.sum();
        long total = h + m;
        double hitRate = total == 0 ? 0.0 : ((double) h / (double) total);
        return new CacheStats(h, m, hitRate);
    }

    private static String str(Map<String, Object> body, String key, String def) {
        if (body == null) {
            return def;
        }
        Object v = body.get(key);
        if (v == null) {
            return def;
        }
        String s = Objects.toString(v, "").trim();
        return s.isEmpty() ? def : s;
    }

    private record CacheEntry<T>(T value, long expiresAtMs) {
        boolean isExpired() {
            return System.currentTimeMillis() > expiresAtMs;
        }
    }
}

