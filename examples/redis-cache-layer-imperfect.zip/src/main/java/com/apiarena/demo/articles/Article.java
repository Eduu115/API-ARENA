package com.apiarena.demo.articles;

import java.time.Instant;

public record Article(
        long id,
        String title,
        String content,
        String author,
        Instant updatedAt
) {}

