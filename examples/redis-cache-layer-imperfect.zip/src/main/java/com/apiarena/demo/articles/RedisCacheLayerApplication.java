package com.apiarena.demo.articles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisCacheLayerApplication {
    public static void main(String[] args) {
        SpringApplication.run(RedisCacheLayerApplication.class, args);
    }
}

