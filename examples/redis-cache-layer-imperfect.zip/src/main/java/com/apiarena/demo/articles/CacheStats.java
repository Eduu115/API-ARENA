package com.apiarena.demo.articles;

public record CacheStats(
        long hits,
        long misses,
        double hitRate
) {}

