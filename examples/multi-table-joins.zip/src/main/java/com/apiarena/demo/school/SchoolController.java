package com.apiarena.demo.school;

import jakarta.annotation.PostConstruct;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
public class SchoolController {

    private final Map<Long, Student> students = new LinkedHashMap<>();
    private final Map<Long, Course> courses = new LinkedHashMap<>();

    @PostConstruct
    void seed() {
        courses.put(1L, new Course(1L, "Introduction to Java", "Prof. Oak"));
        courses.put(2L, new Course(2L, "Database Design", "Prof. Elm"));
        courses.put(3L, new Course(3L, "Web APIs", "Prof. Birch"));
        courses.put(4L, new Course(4L, "Algorithms", "Prof. Rowan"));

        students.put(1L, new Student(1L, "Alice", "alice@school.dev", List.of(1L, 2L)));
        students.put(2L, new Student(2L, "Bob", "bob@school.dev", List.of(2L, 3L)));
        students.put(3L, new Student(3L, "Charlie", "charlie@school.dev", List.of(1L, 3L, 4L)));
        students.put(4L, new Student(4L, "Diana", "diana@school.dev", List.of(4L)));
        students.put(5L, new Student(5L, "Eve", "eve@school.dev", List.of(1L, 2L, 3L, 4L)));
    }

    @GetMapping("/api/students")
    public List<Student> listStudents() {
        return new ArrayList<>(students.values());
    }

    @GetMapping("/api/students/{id}/courses")
    public ResponseEntity<?> studentCourses(@PathVariable Long id) {
        Student s = students.get(id);
        if (s == null) return ResponseEntity.notFound().build();
        List<Course> enrolled = s.getCourseIds().stream()
                .map(courses::get)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        return ResponseEntity.ok(Map.of("student", s.getName(), "courses", enrolled));
    }

    @GetMapping("/api/courses/{id}/students")
    public ResponseEntity<?> courseStudents(@PathVariable Long id) {
        Course c = courses.get(id);
        if (c == null) return ResponseEntity.notFound().build();
        List<Map<String, Object>> enrolled = students.values().stream()
                .filter(s -> s.getCourseIds().contains(id))
                .map(s -> Map.<String, Object>of("id", s.getId(), "name", s.getName(), "email", s.getEmail()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(Map.of("course", c.getTitle(), "students", enrolled));
    }

    @GetMapping("/api/stats")
    public Map<String, Object> stats() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalStudents", students.size());
        result.put("totalCourses", courses.size());
        double avg = students.values().stream()
                .mapToInt(s -> s.getCourseIds().size())
                .average().orElse(0);
        result.put("averageCoursesPerStudent", Math.round(avg * 100.0) / 100.0);
        String mostPopular = courses.entrySet().stream()
                .max(Comparator.comparingLong(e ->
                        students.values().stream().filter(s -> s.getCourseIds().contains(e.getKey())).count()))
                .map(e -> e.getValue().getTitle())
                .orElse("N/A");
        result.put("mostPopularCourse", mostPopular);
        return result;
    }
}
