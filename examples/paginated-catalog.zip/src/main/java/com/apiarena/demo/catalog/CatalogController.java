package com.apiarena.demo.catalog;

import jakarta.annotation.PostConstruct;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
public class CatalogController {

    private final List<Product> products = new ArrayList<>();

    @PostConstruct
    void seed() {
        products.add(new Product(1L, "Wireless Mouse", 29.99, "electronics"));
        products.add(new Product(2L, "Mechanical Keyboard", 79.99, "electronics"));
        products.add(new Product(3L, "USB-C Hub", 45.00, "electronics"));
        products.add(new Product(4L, "Standing Desk", 349.99, "furniture"));
        products.add(new Product(5L, "Monitor Arm", 89.99, "furniture"));
        products.add(new Product(6L, "Desk Lamp", 34.50, "furniture"));
        products.add(new Product(7L, "Notebook A5", 5.99, "stationery"));
        products.add(new Product(8L, "Gel Pen Set", 12.50, "stationery"));
        products.add(new Product(9L, "Laptop Sleeve", 24.99, "accessories"));
        products.add(new Product(10L, "Webcam HD", 59.99, "electronics"));
        products.add(new Product(11L, "Ergonomic Chair", 499.00, "furniture"));
        products.add(new Product(12L, "Cable Organizer", 9.99, "accessories"));
    }

    @GetMapping("/api/products")
    public ResponseEntity<?> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String sort) {

        List<Product> filtered = products;
        if (category != null && !category.isBlank()) {
            filtered = filtered.stream()
                    .filter(p -> p.getCategory().equalsIgnoreCase(category))
                    .collect(Collectors.toList());
        }
        if ("price".equalsIgnoreCase(sort)) {
            filtered = filtered.stream()
                    .sorted(Comparator.comparingDouble(Product::getPrice))
                    .collect(Collectors.toList());
        } else if ("name".equalsIgnoreCase(sort)) {
            filtered = filtered.stream()
                    .sorted(Comparator.comparing(Product::getName))
                    .collect(Collectors.toList());
        }

        int total = filtered.size();
        int from = Math.min(page * size, total);
        int to = Math.min(from + size, total);
        List<Product> pageItems = filtered.subList(from, to);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("content", pageItems);
        resp.put("page", page);
        resp.put("size", size);
        resp.put("totalElements", total);
        resp.put("totalPages", (int) Math.ceil((double) total / size));
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/api/products/{id}")
    public ResponseEntity<Product> getById(@PathVariable Long id) {
        return products.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/api/categories")
    public ResponseEntity<List<String>> categories() {
        List<String> cats = products.stream()
                .map(Product::getCategory)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
        return ResponseEntity.ok(cats);
    }
}
