package com.apiarena.demo.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Imperfect solution. Known flaws (deliberate, to score below the perfect one):
 *  - GET list returns an envelope object instead of a JSON array (design + correctness penalty)
 *  - GET list sleeps ~70ms (tanks performance + latency-weighted correctness)
 *  - POST create returns 200 instead of 201 (functional status mismatch)
 *  - No idempotency: a repeated key creates a duplicate charge
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/payments")
public class PaymentsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaymentsApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public PaymentsApplication() {
        long id = seq.getAndIncrement();
        store.put(id, payment(id, 1000L));
    }

    private Map<String, Object> payment(long id, long amount) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("id", id);
        p.put("amount", amount);
        p.put("status", "CREATED");
        p.put("events", new ArrayList<>(List.of(Map.of("type", "CREATED"))));
        return p;
    }

    @GetMapping
    public Map<String, Object> list() {
        try { Thread.sleep(70); } catch (InterruptedException ignored) { }
        Map<String, Object> envelope = new LinkedHashMap<>();
        envelope.put("data", new ArrayList<>(store.values()));
        envelope.put("count", store.size());
        return envelope; // FLAW: object, not array
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        long amount = body != null && body.get("amount") instanceof Number n ? n.longValue() : 100L;
        long id = seq.getAndIncrement();
        Map<String, Object> p = payment(id, amount);
        store.put(id, p);
        return ResponseEntity.ok(p); // FLAW: should be 201
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> p = store.get(id);
        return p != null ? ResponseEntity.ok(p) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/{id}/capture")
    public ResponseEntity<Map<String, Object>> capture(@PathVariable long id) {
        Map<String, Object> p = store.get(id);
        if (p == null) return ResponseEntity.notFound().build();
        p.put("status", "CAPTURED");
        ((List<Object>) p.get("events")).add(Map.of("type", "CAPTURED"));
        return ResponseEntity.ok(p);
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/events")
    public ResponseEntity<List<Object>> events(@PathVariable long id) {
        Map<String, Object> p = store.get(id);
        return p != null ? ResponseEntity.ok((List<Object>) p.get("events")) : ResponseEntity.notFound().build();
    }
}
