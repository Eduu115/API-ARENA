package com.apiarena.demo.timeseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Reference solution (perfect): high-throughput time-series ingestion.
 * Points are appended in batches; reads return recent points and a downsampled
 * aggregate. The read path is in-memory and allocation-light.
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/series")
public class TimeSeriesApplication {

    public static void main(String[] args) {
        SpringApplication.run(TimeSeriesApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public TimeSeriesApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> s = series(id, "seed-series");
        appendPoint(s, System.currentTimeMillis(), 42.0);
        store.put(id, s);
    }

    private Map<String, Object> series(long id, String name) {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("id", id);
        s.put("name", name);
        s.put("points", new CopyOnWriteArrayList<Map<String, Object>>());
        return s;
    }

    @SuppressWarnings("unchecked")
    private void appendPoint(Map<String, Object> s, long ts, double value) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("ts", ts);
        p.put("value", value);
        ((List<Map<String, Object>>) s.get("points")).add(p);
    }

    private Map<String, Object> summary(Map<String, Object> s) {
        Map<String, Object> v = new LinkedHashMap<>();
        v.put("id", s.get("id"));
        v.put("name", s.get("name"));
        v.put("count", ((List<?>) s.get("points")).size());
        return v;
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> s : store.values()) out.add(summary(s));
        return out;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        String name = body != null && body.get("name") != null ? body.get("name").toString() : "series";
        long id = seq.getAndIncrement();
        Map<String, Object> s = series(id, name);
        store.put(id, s);
        return ResponseEntity.status(201).body(summary(s));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> s = store.get(id);
        return s != null ? ResponseEntity.ok(summary(s)) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/points")
    public ResponseEntity<List<Map<String, Object>>> points(@PathVariable long id) {
        Map<String, Object> s = store.get(id);
        return s != null
                ? ResponseEntity.ok((List<Map<String, Object>>) s.get("points"))
                : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/{id}/points")
    public ResponseEntity<Map<String, Object>> ingest(@PathVariable long id,
            @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> s = store.get(id);
        if (s == null) return ResponseEntity.notFound().build();
        int written = 0;
        long now = System.currentTimeMillis();
        if (body != null && body.get("points") instanceof List<?> batch) {
            for (Object o : batch) {
                if (o instanceof Map<?, ?> pt) {
                    double v = pt.get("value") instanceof Number n ? n.doubleValue() : 0.0;
                    appendPoint(s, now, v);
                    written++;
                }
            }
        }
        if (written == 0) { // single-point or empty body: still ingest one
            double v = body != null && body.get("value") instanceof Number n ? n.doubleValue() : 0.0;
            appendPoint(s, now, v);
            written = 1;
        }
        Map<String, Object> ack = new LinkedHashMap<>();
        ack.put("seriesId", id);
        ack.put("written", written);
        return ResponseEntity.status(201).body(ack);
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/aggregate")
    public ResponseEntity<Map<String, Object>> aggregate(@PathVariable long id) {
        Map<String, Object> s = store.get(id);
        if (s == null) return ResponseEntity.notFound().build();
        List<Map<String, Object>> pts = (List<Map<String, Object>>) s.get("points");
        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE, sum = 0;
        for (Map<String, Object> p : pts) {
            double v = p.get("value") instanceof Number n ? n.doubleValue() : 0.0;
            min = Math.min(min, v); max = Math.max(max, v); sum += v;
        }
        Map<String, Object> agg = new LinkedHashMap<>();
        agg.put("count", pts.size());
        agg.put("min", pts.isEmpty() ? 0.0 : min);
        agg.put("max", pts.isEmpty() ? 0.0 : max);
        agg.put("avg", pts.isEmpty() ? 0.0 : sum / pts.size());
        return ResponseEntity.ok(agg);
    }
}
