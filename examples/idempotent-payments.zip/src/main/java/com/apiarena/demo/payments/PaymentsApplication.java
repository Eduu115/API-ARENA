package com.apiarena.demo.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Reference solution (perfect): idempotent payment API.
 * A repeated Idempotency-Key returns the original payment (no duplicate charge),
 * capture is idempotent, and every state change is an appended event.
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/payments")
public class PaymentsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaymentsApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final Map<String, Long> byKey = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public PaymentsApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> p = payment(id, "seed-key-1", 1000L);
        store.put(id, p);
        byKey.put("seed-key-1", id);
    }

    private Map<String, Object> event(String type) {
        Map<String, Object> e = new LinkedHashMap<>();
        e.put("type", type);
        e.put("at", System.currentTimeMillis());
        return e;
    }

    private Map<String, Object> payment(long id, String key, long amount) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("id", id);
        p.put("idempotencyKey", key);
        p.put("amount", amount);
        p.put("status", "CREATED");
        List<Map<String, Object>> events = new CopyOnWriteArrayList<>();
        events.add(event("CREATED"));
        p.put("events", events);
        return p;
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        return new ArrayList<>(store.values());
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(
            @RequestHeader(value = "Idempotency-Key", required = false) String key,
            @RequestBody(required = false) Map<String, Object> body) {
        String k = key != null && !key.isBlank() ? key : UUID.randomUUID().toString();
        Long existing = byKey.get(k);
        if (existing != null) {
            // Replay: same key returns the original payment, never a second charge.
            return ResponseEntity.status(201).body(store.get(existing));
        }
        long amount = body != null && body.get("amount") instanceof Number n ? n.longValue() : 100L;
        long id = seq.getAndIncrement();
        Map<String, Object> p = payment(id, k, amount);
        store.put(id, p);
        byKey.put(k, id);
        return ResponseEntity.status(201).body(p);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> p = store.get(id);
        return p != null ? ResponseEntity.ok(p) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/{id}/capture")
    public ResponseEntity<Map<String, Object>> capture(@PathVariable long id) {
        Map<String, Object> p = store.get(id);
        if (p == null) return ResponseEntity.notFound().build();
        if (!"CAPTURED".equals(p.get("status"))) {
            p.put("status", "CAPTURED");
            ((List<Map<String, Object>>) p.get("events")).add(event("CAPTURED"));
        }
        return ResponseEntity.ok(p); // idempotent: second capture returns same state
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/events")
    public ResponseEntity<List<Map<String, Object>>> events(@PathVariable long id) {
        Map<String, Object> p = store.get(id);
        return p != null
                ? ResponseEntity.ok((List<Map<String, Object>>) p.get("events"))
                : ResponseEntity.notFound().build();
    }
}
