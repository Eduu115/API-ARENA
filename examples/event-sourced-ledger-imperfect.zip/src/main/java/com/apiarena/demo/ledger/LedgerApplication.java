package com.apiarena.demo.ledger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Imperfect solution. Deliberate flaws:
 *  - GET list returns an envelope object + sleeps ~70ms
 *  - Stores a mutable balance field instead of folding events (not event-sourced)
 *  - POST /{id}/transactions returns 200 instead of 201
 *  - No overdraft protection
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/accounts")
public class LedgerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LedgerApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public LedgerApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> acc = account(id, "seed-account");
        acc.put("balance", 1000L);
        store.put(id, acc);
    }

    private Map<String, Object> account(long id, String owner) {
        Map<String, Object> a = new LinkedHashMap<>();
        a.put("id", id);
        a.put("owner", owner);
        a.put("balance", 0L);
        a.put("transactions", new CopyOnWriteArrayList<Map<String, Object>>());
        return a;
    }

    @GetMapping
    public Map<String, Object> list() {
        try { Thread.sleep(70); } catch (InterruptedException ignored) { }
        Map<String, Object> env = new LinkedHashMap<>();
        env.put("data", new ArrayList<>(store.values()));
        env.put("count", store.size());
        return env;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        String owner = body != null && body.get("owner") != null ? body.get("owner").toString() : "anonymous";
        long id = seq.getAndIncrement();
        Map<String, Object> acc = account(id, owner);
        store.put(id, acc);
        return ResponseEntity.status(201).body(acc);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> a = store.get(id);
        return a != null ? ResponseEntity.ok(a) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/transactions")
    public ResponseEntity<List<Map<String, Object>>> transactions(@PathVariable long id) {
        Map<String, Object> a = store.get(id);
        return a != null
                ? ResponseEntity.ok((List<Map<String, Object>>) a.get("transactions"))
                : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/{id}/transactions")
    public ResponseEntity<Map<String, Object>> addTransaction(@PathVariable long id,
            @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> a = store.get(id);
        if (a == null) return ResponseEntity.notFound().build();
        long amount = body != null && body.get("amount") instanceof Number n ? n.longValue() : 0L;
        Map<String, Object> tx = new LinkedHashMap<>();
        tx.put("type", "DEPOSIT");
        tx.put("amount", amount);
        ((List<Map<String, Object>>) a.get("transactions")).add(tx);
        a.put("balance", (a.get("balance") instanceof Number n ? n.longValue() : 0L) + amount);
        return ResponseEntity.ok(a); // FLAW: should be 201
    }
}
