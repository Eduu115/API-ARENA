package com.apiarena.demo.timeseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Imperfect solution. Deliberate flaws:
 *  - GET list returns an envelope object + sleeps ~70ms (kills throughput score)
 *  - POST /{id}/points returns 200 instead of 201
 *  - aggregate recomputes from scratch every call with no batching considerations
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/series")
public class TimeSeriesApplication {

    public static void main(String[] args) {
        SpringApplication.run(TimeSeriesApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public TimeSeriesApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> s = series(id, "seed-series");
        ((List<Map<String, Object>>) s.get("points")).add(point(42.0));
        store.put(id, s);
    }

    private Map<String, Object> series(long id, String name) {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("id", id);
        s.put("name", name);
        s.put("points", new CopyOnWriteArrayList<Map<String, Object>>());
        return s;
    }

    private Map<String, Object> point(double v) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("ts", System.currentTimeMillis());
        p.put("value", v);
        return p;
    }

    @GetMapping
    public Map<String, Object> list() {
        try { Thread.sleep(70); } catch (InterruptedException ignored) { }
        Map<String, Object> env = new LinkedHashMap<>();
        env.put("data", new ArrayList<>(store.values()));
        env.put("count", store.size());
        return env;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        String name = body != null && body.get("name") != null ? body.get("name").toString() : "series";
        long id = seq.getAndIncrement();
        store.put(id, series(id, name));
        return ResponseEntity.status(201).body(store.get(id));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> s = store.get(id);
        return s != null ? ResponseEntity.ok(s) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/points")
    public ResponseEntity<List<Map<String, Object>>> points(@PathVariable long id) {
        Map<String, Object> s = store.get(id);
        return s != null
                ? ResponseEntity.ok((List<Map<String, Object>>) s.get("points"))
                : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/{id}/points")
    public ResponseEntity<Map<String, Object>> ingest(@PathVariable long id,
            @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> s = store.get(id);
        if (s == null) return ResponseEntity.notFound().build();
        double v = body != null && body.get("value") instanceof Number n ? n.doubleValue() : 0.0;
        ((List<Map<String, Object>>) s.get("points")).add(point(v));
        return ResponseEntity.ok(Map.of("seriesId", id, "written", 1)); // FLAW: should be 201
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/aggregate")
    public ResponseEntity<Map<String, Object>> aggregate(@PathVariable long id) {
        Map<String, Object> s = store.get(id);
        if (s == null) return ResponseEntity.notFound().build();
        List<Map<String, Object>> pts = (List<Map<String, Object>>) s.get("points");
        double sum = 0;
        for (Map<String, Object> p : pts) sum += p.get("value") instanceof Number n ? n.doubleValue() : 0.0;
        return ResponseEntity.ok(Map.of("count", pts.size(), "avg", pts.isEmpty() ? 0.0 : sum / pts.size()));
    }
}
