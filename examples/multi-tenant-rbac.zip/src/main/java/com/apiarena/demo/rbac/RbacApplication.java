package com.apiarena.demo.rbac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Reference solution (perfect): multi-tenant API with role-based access.
 * Members are always scoped to their tenant; cross-tenant ids resolve to 404.
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/tenants")
public class RbacApplication {

    public static void main(String[] args) {
        SpringApplication.run(RbacApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public RbacApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> t = tenant(id, "seed-tenant");
        addMember(t, "owner@seed.dev", "OWNER");
        store.put(id, t);
    }

    private Map<String, Object> tenant(long id, String name) {
        Map<String, Object> t = new LinkedHashMap<>();
        t.put("id", id);
        t.put("name", name);
        t.put("members", new CopyOnWriteArrayList<Map<String, Object>>());
        return t;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> addMember(Map<String, Object> t, String email, String role) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("tenantId", t.get("id"));
        m.put("email", email);
        m.put("role", role);
        ((List<Map<String, Object>>) t.get("members")).add(m);
        return m;
    }

    private Map<String, Object> summary(Map<String, Object> t) {
        Map<String, Object> v = new LinkedHashMap<>();
        v.put("id", t.get("id"));
        v.put("name", t.get("name"));
        return v;
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> t : store.values()) out.add(summary(t));
        return out;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        String name = body != null && body.get("name") != null ? body.get("name").toString() : "tenant";
        long id = seq.getAndIncrement();
        Map<String, Object> t = tenant(id, name);
        addMember(t, "owner@" + id + ".dev", "OWNER");
        store.put(id, t);
        return ResponseEntity.status(201).body(summary(t));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> t = store.get(id);
        return t != null ? ResponseEntity.ok(summary(t)) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/members")
    public ResponseEntity<List<Map<String, Object>>> members(@PathVariable long id) {
        Map<String, Object> t = store.get(id);
        // tenant-scoped: only this tenant's members are ever returned
        return t != null
                ? ResponseEntity.ok((List<Map<String, Object>>) t.get("members"))
                : ResponseEntity.notFound().build();
    }

    @PostMapping("/{id}/members")
    public ResponseEntity<Map<String, Object>> invite(@PathVariable long id,
            @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> t = store.get(id);
        if (t == null) return ResponseEntity.notFound().build();
        String email = body != null && body.get("email") != null ? body.get("email").toString() : "member@invited.dev";
        String role = body != null && Set.of("OWNER", "ADMIN", "MEMBER").contains(body.get("role"))
                ? body.get("role").toString() : "MEMBER";
        return ResponseEntity.status(201).body(addMember(t, email, role));
    }
}
