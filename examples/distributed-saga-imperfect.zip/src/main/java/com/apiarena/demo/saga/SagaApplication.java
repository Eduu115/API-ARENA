package com.apiarena.demo.saga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Imperfect solution. Deliberate flaws:
 *  - GET /api/orders returns an envelope object + sleeps ~70ms
 *  - POST /api/orders returns 200 instead of 201
 *  - cancel sets status but never records compensation (no real rollback)
 */
@SpringBootApplication
@RestController
public class SagaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SagaApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public SagaApplication() {
        long id = seq.getAndIncrement();
        store.put(id, order(id, "COMPLETED"));
    }

    private Map<String, Object> order(long id, String status) {
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("id", id);
        o.put("status", status);
        return o;
    }

    @GetMapping("/api/orders")
    public Map<String, Object> list() {
        try { Thread.sleep(70); } catch (InterruptedException ignored) { }
        Map<String, Object> env = new LinkedHashMap<>();
        env.put("data", new ArrayList<>(store.values()));
        env.put("count", store.size());
        return env;
    }

    @PostMapping("/api/orders")
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        long id = seq.getAndIncrement();
        Map<String, Object> o = order(id, "COMPLETED");
        store.put(id, o);
        return ResponseEntity.ok(o); // FLAW: should be 201
    }

    @GetMapping("/api/orders/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> o = store.get(id);
        return o != null ? ResponseEntity.ok(o) : ResponseEntity.notFound().build();
    }

    @PostMapping("/api/orders/{id}/cancel")
    public ResponseEntity<Map<String, Object>> cancel(@PathVariable long id) {
        Map<String, Object> o = store.get(id);
        if (o == null) return ResponseEntity.notFound().build();
        o.put("status", "CANCELLED"); // FLAW: no compensation recorded
        return ResponseEntity.ok(o);
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP");
    }
}
