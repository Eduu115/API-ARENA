package com.apiarena.demo.rbac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Imperfect solution. Deliberate flaws:
 *  - GET list returns an envelope object + sleeps ~70ms
 *  - GET /{id}/members leaks EVERY tenant's members (no tenant scoping)
 *  - POST /{id}/members returns 200 instead of 201, ignores role validation
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/tenants")
public class RbacApplication {

    public static void main(String[] args) {
        SpringApplication.run(RbacApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final List<Map<String, Object>> allMembers = new CopyOnWriteArrayList<>();
    private final AtomicLong seq = new AtomicLong(1);

    public RbacApplication() {
        long id = seq.getAndIncrement();
        store.put(id, tenant(id, "seed-tenant"));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("tenantId", id); m.put("email", "owner@seed.dev"); m.put("role", "OWNER");
        allMembers.add(m);
    }

    private Map<String, Object> tenant(long id, String name) {
        Map<String, Object> t = new LinkedHashMap<>();
        t.put("id", id);
        t.put("name", name);
        return t;
    }

    @GetMapping
    public Map<String, Object> list() {
        try { Thread.sleep(70); } catch (InterruptedException ignored) { }
        Map<String, Object> env = new LinkedHashMap<>();
        env.put("data", new ArrayList<>(store.values()));
        env.put("count", store.size());
        return env;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        String name = body != null && body.get("name") != null ? body.get("name").toString() : "tenant";
        long id = seq.getAndIncrement();
        Map<String, Object> t = tenant(id, name);
        store.put(id, t);
        return ResponseEntity.status(201).body(t);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> t = store.get(id);
        return t != null ? ResponseEntity.ok(t) : ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}/members")
    public ResponseEntity<List<Map<String, Object>>> members(@PathVariable long id) {
        if (!store.containsKey(id)) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(allMembers); // FLAW: leaks all tenants' members
    }

    @PostMapping("/{id}/members")
    public ResponseEntity<Map<String, Object>> invite(@PathVariable long id,
            @RequestBody(required = false) Map<String, Object> body) {
        if (!store.containsKey(id)) return ResponseEntity.notFound().build();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("tenantId", id);
        m.put("email", body != null && body.get("email") != null ? body.get("email").toString() : "m@x.dev");
        m.put("role", body != null && body.get("role") != null ? body.get("role").toString() : "MEMBER");
        allMembers.add(m);
        return ResponseEntity.ok(m); // FLAW: should be 201
    }
}
