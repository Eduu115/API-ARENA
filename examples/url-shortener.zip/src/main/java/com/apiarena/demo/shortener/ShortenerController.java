package com.apiarena.demo.shortener;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

@RestController
public class ShortenerController {

    private static final String CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private final Map<String, ShortenedUrl> store = new ConcurrentHashMap<>();

    @PostMapping("/api/shorten")
    public ResponseEntity<?> shorten(@RequestBody Map<String, String> body) {
        String url = body.get("url");
        if (url == null || url.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "url is required"));
        }
        String code = generateCode(6);
        while (store.containsKey(code)) {
            code = generateCode(6);
        }
        ShortenedUrl entry = new ShortenedUrl(code, url);
        store.put(code, entry);
        return ResponseEntity.status(201).body(Map.of(
                "code", code,
                "shortUrl", "/" + code,
                "originalUrl", url));
    }

    @GetMapping("/{code}")
    public ResponseEntity<?> redirect(@PathVariable String code) {
        ShortenedUrl entry = store.get(code);
        if (entry == null) {
            return ResponseEntity.notFound().build();
        }
        entry.incrementHits();
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(URI.create(entry.getOriginalUrl()));
        return ResponseEntity.status(302).headers(headers).build();
    }

    @GetMapping("/api/stats/{code}")
    public ResponseEntity<?> stats(@PathVariable String code) {
        ShortenedUrl entry = store.get(code);
        if (entry == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Map.of(
                "code", entry.getCode(),
                "originalUrl", entry.getOriginalUrl(),
                "hits", entry.getHits(),
                "createdAt", entry.getCreatedAt().toString()));
    }

    private String generateCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(CHARS.charAt(ThreadLocalRandom.current().nextInt(CHARS.length())));
        }
        return sb.toString();
    }
}
