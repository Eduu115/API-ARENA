package com.apiarena.demo.shortener;

import java.time.Instant;

public class ShortenedUrl {
    private String code;
    private String originalUrl;
    private Instant createdAt;
    private long hits;

    public ShortenedUrl() {}

    public ShortenedUrl(String code, String originalUrl) {
        this.code = code;
        this.originalUrl = originalUrl;
        this.createdAt = Instant.now();
        this.hits = 0;
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getOriginalUrl() { return originalUrl; }
    public void setOriginalUrl(String originalUrl) { this.originalUrl = originalUrl; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public long getHits() { return hits; }
    public void setHits(long hits) { this.hits = hits; }
    public void incrementHits() { this.hits++; }
}
