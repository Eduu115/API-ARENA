package com.apiarena.demo.auth;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final Map<Long, User> users = new ConcurrentHashMap<>();
    private final Map<String, Long> tokenStore = new ConcurrentHashMap<>();
    private final Map<String, Long> refreshStore = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User body) {
        if (body.getUsername() == null || body.getPassword() == null || body.getEmail() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "username, email and password required"));
        }
        boolean taken = users.values().stream().anyMatch(u -> u.getUsername().equals(body.getUsername()));
        if (taken) {
            return ResponseEntity.status(409).body(Map.of("error", "username already taken"));
        }
        long id = seq.getAndIncrement();
        User user = new User(id, body.getUsername(), body.getEmail(), body.getPassword());
        users.put(id, user);

        String token = UUID.randomUUID().toString();
        String refresh = UUID.randomUUID().toString();
        tokenStore.put(token, id);
        refreshStore.put(refresh, id);

        return ResponseEntity.status(201).body(Map.of(
                "id", id, "username", user.getUsername(),
                "token", token, "refreshToken", refresh));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");
        Optional<User> found = users.values().stream()
                .filter(u -> u.getUsername().equals(username) && u.getPassword().equals(password))
                .findFirst();
        if (found.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("error", "invalid credentials"));
        }
        User user = found.get();
        String token = UUID.randomUUID().toString();
        String refresh = UUID.randomUUID().toString();
        tokenStore.put(token, user.getId());
        refreshStore.put(refresh, user.getId());
        return ResponseEntity.ok(Map.of("token", token, "refreshToken", refresh));
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody Map<String, String> body) {
        String refreshToken = body.get("refreshToken");
        Long userId = refreshStore.remove(refreshToken);
        if (userId == null) {
            return ResponseEntity.status(401).body(Map.of("error", "invalid refresh token"));
        }
        String newToken = UUID.randomUUID().toString();
        String newRefresh = UUID.randomUUID().toString();
        tokenStore.put(newToken, userId);
        refreshStore.put(newRefresh, userId);
        return ResponseEntity.ok(Map.of("token", newToken, "refreshToken", newRefresh));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(Map.of("error", "missing or invalid token"));
        }
        String token = authHeader.substring(7);
        Long userId = tokenStore.get(token);
        if (userId == null) {
            return ResponseEntity.status(401).body(Map.of("error", "invalid token"));
        }
        User user = users.get(userId);
        if (user == null) {
            return ResponseEntity.status(404).body(Map.of("error", "user not found"));
        }
        return ResponseEntity.ok(Map.of("id", user.getId(), "username", user.getUsername(), "email", user.getEmail()));
    }
}
