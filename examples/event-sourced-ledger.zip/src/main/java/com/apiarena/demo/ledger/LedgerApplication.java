package com.apiarena.demo.ledger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Reference solution (perfect): event-sourced ledger.
 * The balance is never stored; it is folded from an append-only transaction log on read.
 */
@SpringBootApplication
@RestController
@RequestMapping("/api/accounts")
public class LedgerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LedgerApplication.class, args);
    }

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public LedgerApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> acc = account(id, "seed-account");
        append(acc, "DEPOSIT", 1000L);
        store.put(id, acc);
    }

    private Map<String, Object> account(long id, String owner) {
        Map<String, Object> a = new LinkedHashMap<>();
        a.put("id", id);
        a.put("owner", owner);
        a.put("transactions", new CopyOnWriteArrayList<Map<String, Object>>());
        return a;
    }

    @SuppressWarnings("unchecked")
    private void append(Map<String, Object> acc, String type, long amount) {
        Map<String, Object> tx = new LinkedHashMap<>();
        tx.put("type", type);
        tx.put("amount", amount);
        tx.put("at", System.currentTimeMillis());
        ((List<Map<String, Object>>) acc.get("transactions")).add(tx);
    }

    @SuppressWarnings("unchecked")
    private long balanceOf(Map<String, Object> acc) {
        long balance = 0;
        for (Map<String, Object> tx : (List<Map<String, Object>>) acc.get("transactions")) {
            long amt = tx.get("amount") instanceof Number n ? n.longValue() : 0L;
            balance += "WITHDRAW".equals(tx.get("type")) ? -amt : amt;
        }
        return balance;
    }

    private Map<String, Object> view(Map<String, Object> acc) {
        Map<String, Object> v = new LinkedHashMap<>(acc);
        v.put("balance", balanceOf(acc)); // projection derived from the log
        return v;
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> a : store.values()) out.add(view(a));
        return out;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        String owner = body != null && body.get("owner") != null ? body.get("owner").toString() : "anonymous";
        long id = seq.getAndIncrement();
        Map<String, Object> acc = account(id, owner);
        store.put(id, acc);
        return ResponseEntity.status(201).body(view(acc));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> a = store.get(id);
        return a != null ? ResponseEntity.ok(view(a)) : ResponseEntity.notFound().build();
    }

    @SuppressWarnings("unchecked")
    @GetMapping("/{id}/transactions")
    public ResponseEntity<List<Map<String, Object>>> transactions(@PathVariable long id) {
        Map<String, Object> a = store.get(id);
        return a != null
                ? ResponseEntity.ok((List<Map<String, Object>>) a.get("transactions"))
                : ResponseEntity.notFound().build();
    }

    @PostMapping("/{id}/transactions")
    public ResponseEntity<Map<String, Object>> addTransaction(@PathVariable long id,
            @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> a = store.get(id);
        if (a == null) return ResponseEntity.notFound().build();
        String type = body != null && "WITHDRAW".equals(body.get("type")) ? "WITHDRAW" : "DEPOSIT";
        long amount = body != null && body.get("amount") instanceof Number n ? n.longValue() : 0L;
        if ("WITHDRAW".equals(type) && balanceOf(a) - amount < 0) {
            return ResponseEntity.badRequest().build(); // no overdraft
        }
        append(a, type, amount);
        return ResponseEntity.status(201).body(view(a));
    }
}
