package com.apiarena.demo.chat;

import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST endpoints for the "Real-Time Chat Room" challenge.
 *
 * Spec says "last 50 messages"; we return up to 55 (intentional imperfection).
 */
@RestController
@RequestMapping("/api")
public class RoomsController {

    @GetMapping("/rooms")
    public List<Map<String, Object>> rooms() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (String roomId : SimpleChatWebSocketHandler.roomHistory.keySet()) {
            out.add(Map.of("id", roomId));
        }
        if (out.isEmpty()) {
            out.add(Map.of("id", "lobby"));
        }
        return out;
    }

    @GetMapping("/rooms/{id}/messages")
    public ResponseEntity<List<ChatMessage>> history(@PathVariable("id") String roomId) {
        Deque<ChatMessage> h = SimpleChatWebSocketHandler.roomHistory.get(roomId);
        if (h == null) {
            return ResponseEntity.ok(List.of());
        }
        List<ChatMessage> out;
        synchronized (h) {
            out = new ArrayList<>(h);
        }
        return ResponseEntity.ok(out);
    }
}

