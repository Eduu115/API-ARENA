package com.apiarena.demo.chat;

import java.time.Instant;

public record ChatMessage(
        String roomId,
        String user,
        String message,
        Instant timestamp
) {}

