package com.apiarena.demo.chat;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

/**
 * Minimal WS handler for the challenge endpoint "/ws/chat".
 *
 * Protocol: client sends text frames "roomId|user|message".
 *
 * Intentional imperfections (for testing Arena scoring):
 * - Broadcast payload is plain text (not strict JSON schema).
 * - Keeps last 55 messages in memory (spec says 50).
 */
public class SimpleChatWebSocketHandler extends TextWebSocketHandler {

    static final Map<String, Set<WebSocketSession>> roomSessions = new ConcurrentHashMap<>();
    static final Map<String, Deque<ChatMessage>> roomHistory = new ConcurrentHashMap<>();

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws IOException {
        String payload = message.getPayload() == null ? "" : message.getPayload().trim();
        String[] parts = payload.split("\\|", 3);
        String roomId = parts.length > 0 && !parts[0].isBlank() ? parts[0].trim() : "lobby";
        String user = parts.length > 1 && !parts[1].isBlank() ? parts[1].trim() : "anon";
        String text = parts.length > 2 ? parts[2] : "";

        roomSessions.computeIfAbsent(roomId, k -> new CopyOnWriteArraySet<>()).add(session);
        Deque<ChatMessage> history = roomHistory.computeIfAbsent(roomId, k -> new ArrayDeque<>());

        ChatMessage m = new ChatMessage(roomId, user, text, Instant.now());
        synchronized (history) {
            history.addLast(m);
            while (history.size() > 55) {
                history.removeFirst();
            }
        }

        String broadcast = "room=" + roomId + ";user=" + user + ";message=" + text + ";ts=" + m.timestamp();
        for (WebSocketSession s : roomSessions.getOrDefault(roomId, Set.of())) {
            if (s.isOpen()) {
                s.sendMessage(new TextMessage(broadcast));
            }
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        for (Set<WebSocketSession> sessions : roomSessions.values()) {
            sessions.remove(session);
        }
    }
}

