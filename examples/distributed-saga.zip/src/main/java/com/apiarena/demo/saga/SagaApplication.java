package com.apiarena.demo.saga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Reference solution (perfect): saga order orchestration.
 * Creating an order runs payment -> inventory -> shipping in sequence; cancelling
 * runs the compensations in reverse. Saga state is exposed on the order.
 * No class-level mapping so /health stays at the root.
 */
@SpringBootApplication
@RestController
public class SagaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SagaApplication.class, args);
    }

    private static final List<String> STEPS = List.of("payment", "inventory", "shipping");

    private final Map<Long, Map<String, Object>> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public SagaApplication() {
        long id = seq.getAndIncrement();
        Map<String, Object> o = order(id);
        runSaga(o);
        store.put(id, o);
    }

    private Map<String, Object> order(long id) {
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("id", id);
        o.put("status", "PENDING");
        o.put("completedSteps", new CopyOnWriteArrayList<String>());
        return o;
    }

    @SuppressWarnings("unchecked")
    private void runSaga(Map<String, Object> o) {
        List<String> done = (List<String>) o.get("completedSteps");
        done.clear();
        for (String step : STEPS) {
            done.add(step); // each step succeeds in the happy path
        }
        o.put("status", "COMPLETED");
    }

    @SuppressWarnings("unchecked")
    private void compensate(Map<String, Object> o) {
        List<String> done = (List<String>) o.get("completedSteps");
        List<String> reversed = new ArrayList<>(done);
        Collections.reverse(reversed); // compensate in reverse order
        o.put("compensatedSteps", reversed);
        done.clear();
        o.put("status", "COMPENSATED");
    }

    @GetMapping("/api/orders")
    public List<Map<String, Object>> list() {
        return new ArrayList<>(store.values());
    }

    @PostMapping("/api/orders")
    public ResponseEntity<Map<String, Object>> create(@RequestBody(required = false) Map<String, Object> body) {
        long id = seq.getAndIncrement();
        Map<String, Object> o = order(id);
        runSaga(o);
        store.put(id, o);
        return ResponseEntity.status(201).body(o);
    }

    @GetMapping("/api/orders/{id}")
    public ResponseEntity<Map<String, Object>> get(@PathVariable long id) {
        Map<String, Object> o = store.get(id);
        return o != null ? ResponseEntity.ok(o) : ResponseEntity.notFound().build();
    }

    @PostMapping("/api/orders/{id}/cancel")
    public ResponseEntity<Map<String, Object>> cancel(@PathVariable long id) {
        Map<String, Object> o = store.get(id);
        if (o == null) return ResponseEntity.notFound().build();
        compensate(o);
        return ResponseEntity.ok(o);
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        Map<String, Object> h = new LinkedHashMap<>();
        h.put("status", "UP");
        h.put("orchestrator", "ready");
        return h;
    }
}
