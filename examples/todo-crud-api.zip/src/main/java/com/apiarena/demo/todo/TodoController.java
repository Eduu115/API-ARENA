package com.apiarena.demo.todo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/todos")
public class TodoController {

    private final Map<Long, Todo> store = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    @GetMapping
    public List<Todo> list() {
        return new ArrayList<>(store.values());
    }

    @PostMapping
    public ResponseEntity<Todo> create(@RequestBody Todo todo) {
        if (todo.getTitle() == null || todo.getTitle().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        long id = seq.getAndIncrement();
        todo.setId(id);
        if (todo.getPriority() == null) todo.setPriority("MEDIUM");
        store.put(id, todo);
        return ResponseEntity.status(201).body(todo);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Todo> get(@PathVariable Long id) {
        Todo t = store.get(id);
        return t != null ? ResponseEntity.ok(t) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Todo> update(@PathVariable Long id, @RequestBody Todo updated) {
        Todo existing = store.get(id);
        if (existing == null) return ResponseEntity.notFound().build();
        existing.setTitle(updated.getTitle() != null ? updated.getTitle() : existing.getTitle());
        existing.setDescription(updated.getDescription() != null ? updated.getDescription() : existing.getDescription());
        existing.setCompleted(updated.isCompleted());
        if (updated.getPriority() != null) existing.setPriority(updated.getPriority());
        return ResponseEntity.ok(existing);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        return store.remove(id) != null ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PatchMapping("/{id}/complete")
    public ResponseEntity<Todo> complete(@PathVariable Long id) {
        Todo t = store.get(id);
        if (t == null) return ResponseEntity.notFound().build();
        t.setCompleted(true);
        return ResponseEntity.ok(t);
    }
}
