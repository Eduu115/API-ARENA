package com.apiarena.demo.todo;

public class Todo {
    private Long id;
    private String title;
    private String description;
    private boolean completed;
    private String priority; // LOW, MEDIUM, HIGH

    public Todo() {}

    public Todo(Long id, String title, String description, boolean completed, String priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.completed = completed;
        this.priority = priority;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
}
